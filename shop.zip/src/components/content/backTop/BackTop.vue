<template>
  <div class="backTop">
    <img src="~assets/img/common/top.png" alt="">
  </div>
</template>

<script>
 export default{
   name:"BackTop",
 }
</script>

<style>
 .backTop {
    position: fixed;
    right: 8px;
    bottom: 49px;
  }

  .backTop img {
    width: 43px;
    height: 43px;
    display: block;
  }
</style>
