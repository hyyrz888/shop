<template>
  <div id="profile">
  <h2>我的信息</h2>
  <input type="number" placeholder="输入手机号" />
</div>
</template>

<script>
  export default {
    name:'Profile'
  }
</script>

<style scoped>

</style>
