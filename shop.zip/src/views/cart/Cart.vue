<template>
  <div id="cart">
    购物车
  </div>
</template>

<script>
</script>

<style>
</style>
