<template>
  <div id="detail">
    <detail-nav-bar class="detail-nav" @titleClick="titleClick" ref="nav" />
    <scroll class="content" ref="scroll" :probe-type="3" @scroll="contentScroll">
      <detail-swiper :top-images="topImages"></detail-swiper>
      <detail-base-info :goods="goods" />
      <detail-shop-info :shop="shop" />
      <detail-goods-info :detail-info="detailInfo" ref="params" @imageLoad="imageload" />
      <detail-param-info :param-info="paramInfo" />
    </scroll>
    <!--显示返回顶部-->
    <back-top @click.native="backClick" v-if="isShowBackTop" />
  </div>
</template>

<script>
import DetailNavBar from './childComps/DetailNavBar';
import DetailSwiper from './childComps/DetailSwiper';
import DetailBaseInfo from './childComps/DetailBaseInfo';
import DetailShopInfo from './childComps/DetailShopInfo';
import DetailGoodsInfo from './childComps/DetailGoodsInfo';
import DetailParamInfo from './childComps/DetailParamInfo';

import Scroll from 'components/common/scroll/Scroll';

import { getDetails, Goods, Shop, GoodsParam } from 'network/detail';
import { itemListenerMixin, backTopMixin } from 'common/mixin';

export default {
  name: 'Detail',
  components: {
    DetailNavBar,
    DetailSwiper,
    DetailBaseInfo,
    DetailShopInfo,
    DetailGoodsInfo,
    DetailParamInfo,
    Scroll,

  },
  mixins: [itemListenerMixin, backTopMixin],
  data() {
    return {
      iid: null,
      topImages: [],
      goods: {},
      shop: {},
      detailInfo: {},
      paramInfo: {},
      commentInfo: [],
      themeTopYs: [],
      isShowBackTop: false
    };
  },
  created() {
    //1.保存传入的iid
    this.iid = this.$route.params.iid;
    this.getDetail(this.iid);
    //获取数据
    getDetails(this.iid).then(res => {
      //1.获取顶部轮播数据
      const data = res.result;
      //console.log(data);
      this.topImages = data.itemInfo.topImages;

      //2.获取商品信息
      this.goods = new Goods(data.itemInfo, data.columns, data.shopInfo.services);

      //3.创建店铺信息的对象
      this.shop = new Shop(data.shopInfo);

      //4.保存商品的详情数据
      this.detailInfo = data.detailInfo;
      console.log(this.detailInfo);
      //5.获取产品参数信息
      this.paramInfo = new GoodsParam(data.itemParams.info, data.itemParams.rule);

      //6.取出评论的信息
      if (data.rate.cRate !== 0) {
        //评论不为0
        this.commentInfo = data.rate.list[0];
      } else {
        console.log('没用评论!');
      }
    });
  },

  mounted() {},
  methods: {
    getDetail(iid) {
      getDetails(iid).then(res => {
        // console.log(res);
      });
    },
    contentScroll(position) {
      //滑动页面让导航自动跟踪到对面的导航锚点
       



      //是否显示回到顶部
      this.isShowBackTop = -position.y > 1000;
    },
    imageload() {
      //图片内容全部加载完成执行一次刷新
      this.$refs.scroll.refresh();
      this.themeTopYs = [];
      this.themeTopYs.push(0);
      this.themeTopYs.push(this.$refs.params.$el.offsetTop-44);  //参数的起始位置
    },
    titleClick(index) {
      //点击对应的导航锚点页面滑动到指定的位置
      this.$refs.scroll.scrollTo(0, -this.themeTopYs[index], 100);
    }
  }
};
</script>

<style scoped>
#detail {
  position: relative;
  z-index: 9;
  background-color: #fff;
  height: 100vh;
}

.detail-nav {
  position: relative;
  z-index: 9;
  background-color: #fff;
}

.content {
  height: calc(100% - 44px - 49px);
}
</style>
<!--到内页后再点击首页会出现回到了顶部，而我们要保存从首页进来的那个位置，返回首页的时候依旧是之前那个位置-->
